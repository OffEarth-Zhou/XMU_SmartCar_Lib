#ifndef __INIT_H__
#define __INIT_H__


#define SWITCH0_PIN P00_1
#define SWITCH1_PIN P00_2
#define SWITCH2_PIN P00_3
#define SWITCH3_PIN P00_4


void system_Init(void);
void PIT_Init(void);
void ADC_Init(void);







#endif

