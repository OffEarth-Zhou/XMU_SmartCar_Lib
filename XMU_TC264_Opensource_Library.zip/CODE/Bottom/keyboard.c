#include  "common.h"
#include  "keyboard.h"
#include  "headfile.h"

int g_Key = -1;

//*      Key_Scan(void)
//*	@brief:		��ȡ������̵�����״̬��ÿ�����������ض���ֵ
//*	@param:		void
//*	@return:	1~9 δ���¼���ʱ����-1 
//* @note:    void
//*
int Key_Scan(void)
{   
    char Scan_Result;
    gpio_init(ROW1,GPO,0, PUSHPULL);
    gpio_init(ROW2,GPO,0, PUSHPULL);
    gpio_init(ROW3,GPO,0, PUSHPULL);
#ifdef ROW4
    gpio_init(ROW4,GPO,0, PUSHPULL);
#endif
    gpio_init(COL1,GPI,1,PULLUP);
    gpio_init(COL2,GPI,1,PULLUP);
    gpio_init(COL3,GPI,1,PULLUP);

    Scan_Result=gpio_get(COL1);
    Scan_Result+=gpio_get(COL2)<<1;
    Scan_Result+=gpio_get(COL3)<<2;

    if(Scan_Result != 0x07)
    {
    	systick_delay_ms(STM0, 2);
        Scan_Result=Scan_Result<<4;
        gpio_init(COL1,GPO,0, PUSHPULL);
        gpio_init(COL2,GPO,0, PUSHPULL);
        gpio_init(COL3,GPO,0, PUSHPULL);
        gpio_init(ROW1,GPI,1,PULLUP);
        gpio_init(ROW2,GPI,1,PULLUP);
        gpio_init(ROW3,GPI,1,PULLUP);
#ifdef ROW4
        gpio_init(ROW4,GPI,1,PULLUP);
#endif

        systick_delay_ms(STM0,1);
        Scan_Result+=gpio_get(ROW1);
        systick_delay_ms(STM0,1);
        Scan_Result+=gpio_get(ROW2)<<1;
        systick_delay_ms(STM0,1);
        Scan_Result+=gpio_get(ROW3)<<2;
#ifdef ROW4
        systick_delay_ms(STM0,1);
        Scan_Result+=gpio_get(ROW4)<<3;
#endif

        switch(Scan_Result)
        {
#ifdef ROW4
        case 0x37: return 12;break;
        case 0x3B: return 9;break;
        case 0x3D: return 6;break;
        case 0x3E: return 3;break;
        case 0x57: return 11;break;
        case 0x5B: return 8;break;
        case 0x5D: return 5;break;
        case 0x5E: return 2;break;
     case 0x67: return 10;break;
        case 0x6B: return 7;break;
        case 0x6D: return 4;break;
        case 0x6E: return 1;break;
#else
        case 0x33: return 3;break;
        case 0x35: return 6;break;
        case 0x36: return 9;break;
        case 0x53: return 2;break;
        case 0x55: return 5;break;
        case 0x56: return 8;break;
        case 0x63: return 1;break;
        case 0x65: return 4;break;
        case 0x66: return 7;break;
#endif
        default :break;
        }
    }
    return -1;
}


//*    Key_Check(void)
//*	@brief:		���������
//*	@param:		void
//*	@return:	�հ���ȥʱ����ʵ�ʽ�ֵ δ���»��²���ʱ����-1�� 
//* @note:    void
//*


int Key_Check(void)
{
    char last_Key;
    static char temp_Key = -1;

    last_Key = temp_Key;
    temp_Key = (char)Key_Scan();
    if(temp_Key != last_Key)
    {
        return last_Key;
    }
    return -1;
}




