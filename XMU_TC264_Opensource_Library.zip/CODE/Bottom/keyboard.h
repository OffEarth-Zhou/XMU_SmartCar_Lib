#ifndef __KEYBOARD_H__
#define __KEYBOARD_H__

#define ROW1 P00_5
#define ROW2 P00_4
#define ROW3 P00_3
//#define ROW4 P00_7

#define COL1 P00_0
#define COL2 P00_1
#define COL3 P00_2
int Key_Scan(void);
int Key_Check(void);
extern int g_Key;


#endif
