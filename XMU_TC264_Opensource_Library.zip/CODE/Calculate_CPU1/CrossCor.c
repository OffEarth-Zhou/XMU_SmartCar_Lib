#include <Calculate_CPU1/CrossCor.h>
#include "headfile.h"
#include "Ifx_Types.h"
#include "GlobalVariable.h"
#include "SysSe/Math/Ifx_FftF32.h"
#include "mymath.h"


#define PI 3.1415926535
#define SAMPLE_FREQUENCY	100
//��FFT����߾��ȿɲ�ֵ������
void FFT(cfloat32 *Out,uint16 *In,unsigned short N)
{
	cfloat32 In_0[SIZE_N];
	float BP[SIZE_N];
	Bp_Filter(BP,In,N);//������Ӱ������ٶ�
	for(int j=0;j<SIZE_N;j++)
	{
			In_0[j].real=BP[j];
		    In_0[j].imag=0.0;
	}
	Ifx_FftF32_radix2(Out,In_0,N);
}
void FFT2(cfloat32 *Out,uint16 *In,unsigned short N)
{
    cfloat32 In_0[SIZE_N];
	for(int j=0;j<SIZE_N;j++)
	{
			In_0[j].real=In[j]/100;
		    In_0[j].imag=0.0;
	}
	Ifx_FftF32_radix2(Out,In_0,N);
}

//*	@brief:	���л��������
void Cross_Cor(cfloat32 *Cor_Out,cfloat32 *In0,cfloat32 *In1,unsigned short N)
{
	cfloat32 In2[SIZE_N];
   for(int i=0;i < N;i++)//�������
   {
      In2[i].imag=(-In0[i].imag*In1[i].real+In0[i].real*In1[i].imag)/10000;
      In2[i].real= (In0[i].real*In1[i].real+In0[i].imag*In1[i].imag)/10000;
	}
   Ifx_FftF32_radix2I(Cor_Out,In2,N);
}


//��任����ʱ�������
float calculate_d(cfloat32 *Cor_Out)
{
		float Mag[SIZE_N];
			float Max1=0,Max2=0,Max=0;
			int MaxPos1=0,MaxPos2=0,MaxPos=0;
			float T,D;
			for(int i=0; i<20;i++)
			{
				Mag[i]=Cor_Out[i].real*Cor_Out[i].real+Cor_Out[i].imag*Cor_Out[i].imag;
				if(Max1<Mag[i])
				{
					Max1=Mag[i];
				    MaxPos1=i;
				}
//				if(Max1>2800)
//				   Max1=0;
			}
			for(int j=SIZE_N-20;j<SIZE_N;j++)
			{
				Mag[j]=Cor_Out[j].real*Cor_Out[j].real+Cor_Out[j].imag*Cor_Out[j].imag;
				if(Max2<Mag[j])
				{
					Max2=Mag[j];
					MaxPos2=j;
				}
//				if(Max2>2800)
//				   Max2=0;
			}
			if(Max1>=Max2)
			{
				Max=Max1;
				MaxPos=MaxPos1;
			}
			else
			{
				Max=Max2;
				MaxPos=MaxPos2;
			}
			T=MaxPos*0.05;//ms
			D=T/1000*S_SPEED;
			return D;

}
//�������
void Calculate_D(float D1,float D2,float D3,float D4)
{
	static float last_D1,last_D2,last_D3,last_D4;
			    if(D1<=30)
			    	Mic_D1=D1;
			    else
			    	Mic_D1=D1-DIS_Max;
			    if(D3<=30)
			 	   Mic_D3=D3;
			 	else
			 	   Mic_D3=D3-DIS_Max;
			    if(D2<=22)
			   	   Mic_D2=D2;
			   	else
			   	   Mic_D2=D2-DIS_Max;
			    if(D4<=22)
			       Mic_D4=D4;
			    else
			       Mic_D4=D4-DIS_Max;
			    if(Mic_D1<-30||Mic_D1>30)
  		      	   Mic_D1=last_D1;
			    if(Mic_D3<-30||Mic_D3>30)
			    	Mic_D3=last_D3;
			    if(Mic_D2<-22||Mic_D2>22)
			    	Mic_D2=last_D2;
			    if(Mic_D4<-22||Mic_D4>22)
			        Mic_D4=last_D4;
			    last_D1=Mic_D1;
			    last_D2=Mic_D2;
			    last_D3=Mic_D3;
			    last_D4=Mic_D4;
}

//FIR��ͨ�˲���pi/25~2pi/5
void Bp_Filter(float *out,uint16 *in,int n)
{
	float coefficients[26]={ -0.0020,-0.0001,-0.0016,-0.0104,-0.0200,-0.0136,0.0055,-0.0018,-0.0583,
			  -0.1040,-0.0358,0.1563,0.3319,0.3319,0.1563,-0.0358,-0.1040,
			  -0.0583,-0.0018,0.0055,-0.0136,-0.0200,-0.0104,-0.0016,-0.0001,-0.0020};
	float temp;
	  int i,j,k;
	  float state[26+1]={0,0};
	for (k = 0; k < n; k++)
	{
//	  if(in[k]>1800||in[k]<20)
//		  in[k]=0;
	  state[0] = in[k]/100;
	  for (i = 0, temp = 0; i <26; i++)
	  temp += coefficients[i] * state[i];
	  out[k] = temp;
	  for (j = 26-1; j > -1 ; j--)
	  state[j+1] = state[j];
	}
}


//����Chirp�źţ�float fStartF=250,fEndF=2000;
void Chirp(float fStartF, float fEndF, float *Chirp_Buffer)
{
	//float Chirp_Buffer[2048];
	int CHIRP_BUFFER=SIZE_N,DAC_OUTPUT_FREQUENCY=10000;
    float fAngle = 0;
    float fFrequency;
    float fDeltaT = 1.0 / DAC_OUTPUT_FREQUENCY;
    for(int i = 0; i < CHIRP_BUFFER; i ++)
	{
     Chirp_Buffer[i] = (unsigned short)((sin(fAngle * 2 * 3.1415926) + 1.0) / 2 * 0x4ff)+0x100;
     fFrequency = (fEndF - fStartF) * (i + 1) / CHIRP_BUFFER + fStartF;
     fAngle += fFrequency * fDeltaT;
    }
}
//����
cfloat32 conjf(cfloat32 x)
{
	cfloat32 temp;
	temp.imag=-x.imag;
	temp.real=x.real;
	x=temp;
	return x;
}
//��任����2ms
void IFFT(cfloat32 *y,cfloat32*x,unsigned short N)
{
	cfloat32 temp[SIZE_N];
	for(int i = 0; i < N; i++)
		temp[i] = conjf(x[i]);
	Ifx_FftF32_radix2(y,temp,N);
	//memcpy(temp, y,2*N*sizeof(float));
	for(int i = 0; i < N; i++)
	{
		y[i].real = y[i].real/N;
		y[i].imag = -y[i].imag/N;
	}
}

//��һ��fft�㷨������
 void kfft( double pr[], double pi[],int n,int k, double fr[], double fi[])
  {
	int it,m,is,i,j,nv,l0;
    double p,q,s,vr,vi,poddr,poddi;
    for (it=0; it<=n-1; it++)  //��pr��ʵ�����鲿ѭ����ֵ��fr[]��fi[]
    {
		m=it;
		is=0;
		for(i=0; i<=k-1; i++)
        {
			j=m/2;
			is=2*is+(m-2*j);
			m=j;
		}
        fr[it]=pr[is];
        fi[it]=pi[is];
    }
    pr[0]=1.0;
    pi[0]=0.0;
    p=6.283185306/(1.0*n);
    pr[1]=cos(p); //��w=e^-j2pi/n��ŷ����ʽ��ʾ
    pi[1]=-sin(p);
    for (i=2; i<=n-1; i++)  //����pr[]
    {
		p=pr[i-1]*pr[1];
		q=pi[i-1]*pi[1];
		s=(pr[i-1]+pi[i-1])*(pr[1]+pi[1]);
		pr[i]=p-q; pi[i]=s-p-q;
    }
    for (it=0; it<=n-2; it=it+2)
    {
		vr=fr[it];
		vi=fi[it];
		fr[it]=vr+fr[it+1];
		fi[it]=vi+fi[it+1];
		fr[it+1]=vr-fr[it+1];
		fi[it+1]=vi-fi[it+1];
    }
	m=n/2;
	nv=2;
    for (l0=k-2; l0>=0; l0--) //��������
    {
		m=m/2;
		nv=2*nv;
        for (it=0; it<=(m-1)*nv; it=it+nv)
          for (j=0; j<=(nv/2)-1; j++)
            {
				p=pr[m*j]*fr[it+j+nv/2];
				q=pi[m*j]*fi[it+j+nv/2];
				s=pr[m*j]+pi[m*j];
				s=s*(fr[it+j+nv/2]+fi[it+j+nv/2]);
				poddr=p-q;
				poddi=s-p-q;
				fr[it+j+nv/2]=fr[it+j]-poddr;
				fi[it+j+nv/2]=fi[it+j]-poddi;
				fr[it+j]=fr[it+j]+poddr;
				fi[it+j]=fi[it+j]+poddi;
            }
    }
    for (i=0; i<n; i++)
       {
		  pr[i]=sqrt(fr[i]*fr[i]+fi[i]*fi[i]);  //���ȵļ���
       }
  }
//fft��任
void kIfft( double Ipr[], double Ipi[],int n,int k, double Ifr[], double Ifi[])
  {
	int i;
    kfft(Ipr,Ipi,n,k,Ifr,Ifi);
    for (i=0; i<n; i++)
    {
		Ipr[i]=Ipr[i]/n; //������
    }
  }
//*	@brief:	FFT�������
void FFT_test(void)
{
	int X=0;
	cfloat32 fft_in[SIZE_N];
	cfloat32 fft_out[SIZE_N];
	float Chirp_Voice[SIZE_N];
	//float Chirp_Voice1[1024];
	if(X==0)
		 {
	      Chirp(250.0,2000.0,Chirp_Voice);
	     // Bp_Filter(Chirp_Voice1,Chirp_Voice,1204);
	      for(int i=0;i<SIZE_N;i++)
	      {
	    	  fft_in[i].real=Chirp_Voice[i];
	    	  fft_in[i].imag=0.0;
	      }
	      Ifx_FftF32_radix2(fft_out,fft_in,SIZE_N);
	      for(int j=0;j<SIZE_N;j++)
	         {
	    	  if(j>=0&&j<200)
	    	  {
	    	  Chirp_Voice[j]=fft_out[j].real* fft_out[j].real+fft_out[j].imag*fft_out[j].imag;
	    	  Chirp_Voice[j]=my_sqrt( Chirp_Voice[j]);
	    	  printf("%f\n",Chirp_Voice[j]);
	    	  }
	         }
		 }
		  X=1;
}

//void IIR_filter(cfloat32 *y,cfloat32 *x,int n)//��ͨ�˲�,a,b1,b2Ϊϵ��
//{
//    float a=1;
//    float b1=1;
//    float b2=1;
//	y[0].real=a*x[0].real;
//    y[1].real=a*x[1].real-b1*y[0].real;
//    for(int i=0;i<n;i++)
//    {
//    	y[i].imag=0.0;
//    	if(i>1)
//    	{
//    		y[i].real=a*x[i].real-a*x[i-2].real-b1*y[i-1].real-b2*y[i-2].real;
//    		//printf("i: %d\n",i);
//    	}
//    }
//}

