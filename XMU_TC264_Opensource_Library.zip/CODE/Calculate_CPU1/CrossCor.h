
#ifndef CODE_CALCULATE_CPU1_CROSSCOR_H_
#define CODE_CALCULATE_CPU1_CROSSCOR_H_
#include "headfile.h"

void Cross_Cor(cfloat32 *Ifft,cfloat32 *In0,cfloat32 *In1,unsigned short N);
float calculate_d(cfloat32 *Cor_Out);
void Calculate_D(float D1,float D2,float D3,float D4);
void FFT(cfloat32 *Out,uint16 *In,unsigned short N);
void FFT2(cfloat32 *Out,uint16 *In,unsigned short N);
void IFFT(cfloat32 *y,cfloat32*x,unsigned short N);
void Bp_Filter(float *out,uint16 *in,int n);
void Chirp(float fStartF, float fEndF,float *Chirp_Buffer);
//void IIR_filter(cfloat32 *y,cfloat32 *x,int n);
void FFT_test(void);
void kfft( double pr[], double pi[],int n,int k, double fr[], double fi[]);
void kIfft( double Ipr[], double Ipi[],int n,int k, double Ifr[], double Ifi[]);


#endif /* CODE_CALCULATE_CPU1_CROSSCOR_H_ */
