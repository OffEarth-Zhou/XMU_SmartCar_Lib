/*
 * Kalman_Filter.c
 *  Created on: 2020��7��26��
 *      Author: zmd123
 */
#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include "Kalman_Filter.h"

//��ʼ������
kalman_state Kalman_Init={0,0,1,1,0.01,0.543};

 float kalman_filter(kalman_state *state, float z_measure)
 {
     /* Predict */
     state->x = state->A * state->x;
     state->p = state->A * state->A * state->p + state->q;  /* p(n|n-1)=A^2*p(n-1|n-1)+q */
     /* Measurement */
     state->gain = state->p * state->H / (state->p * state->H * state->H + state->r);
     state->x = state->x + state->gain * (z_measure - state->H * state->x);
     state->p = (1 - state->gain * state->H) * state->p;

     return state->x;
 }

double frand()
{ return 2*((rand()/(double)RAND_MAX) - 0.5); // �������
}






