/*
 * Position.c
 *
 *  Created on: 2020��7��3��
 *      Author: zmd123
 */
#include "Position.h"
#include "GlobalVariable.h"
#include <Calculate_CPU1/CrossCor.h>
#include "mymath.h"
#include "math.h"
#include "mpu_prepare.h"
#include "Kalman_Filter.h"

float sound_pwm=0;
float sound_P=6/*2.8*/,sound_D=0/*5*/;
float Sound_Pwm=0;
float sound_P2=/*25*/25,sound_D2=0/*10*/;
float Sound_error = 0,exp_Wz = 0,Wz_error = 0;

void Calculate_Belta(float *B1,float *B2,unsigned short n)
{
	float Variance1=0,Variance2=0;
	Variance1=Variance(B1,n);
	Variance2=Variance(B2,n);
	if(Variance1<=Variance2)
		 {
		    Belta=asinf(my_ave(B1,n))*180/IFX_PI;
		    Belta=my_abs(Belta);
		 }
	else
		{
		    Belta=asinf(my_ave(B2,n))*180/IFX_PI;
		    Belta=90-my_abs(Belta);
		}
}
void Location_Belta(void)//�ж����ޣ����ƫ��
{
	if(Mic_D3>=0)//&&Mic_D2>=0)||(Mic_D3>=0&&Mic_D4>=0)||(Mic_D2>=0&&Mic_D4>=0))
	{
		Front=1;
		Back=0;
		jg_flag = 0;
	}
	else
	{
		Front=0;
		Back=1;
		jg_flag = 1;
	}
	if(Mic_D1>=0)
		{
			Right=1;
			Left=0;
		}
		else
		{
			Right=0;
			Left=1;
		}
	if(Mic_D1==0&&my_abs(Mic_D3)>=27.2)
		Belta=0;
	if(Mic_D1>27.2&&Mic_D3==0)
		Belta=90;
	if(Mic_D3==0&&Mic_D1<=-27.2)
		 Belta=-90;
	     if(Right==1&&Front==1)//�ж�����
	    {
		       g_plane1=1;
		       g_plane2=0;
		       g_plane3=0;
		       g_plane4=0;
	     }
	     if(Left==1&&Front==1)
	     {
			  g_plane2=1;
			  g_plane1=0;
			  g_plane3=0;
			  g_plane4=0;
			  Belta=-Belta;
		 }
		 if(Left==1&&Back==1)
		 {
			g_plane3=1;
			g_plane1=0;
			g_plane2=0;
			g_plane4=0;
		 }
		 if(Right==1&&Back==1)
		 {
			g_plane4=1;
			g_plane1=0;
			g_plane2=0;
			g_plane3=0;
			Belta=-Belta;
		 }
}
/*�ɰ�
//void Find_Sound(float belta)
//{
////	 float Sound_error,exp_Wz,Wz_error;
//	 static float last_sound_err,last_Gyro;
//	 Sound_error=belta - err;
////	 sensor.Gyro_deg.z=-sensor.Gyro_deg.z;
//	 exp_Wz = sound_P * Sound_error + sound_D * (Sound_error - last_sound_err);
//     Wz_error=exp_Wz-sensor.Gyro_deg.z;
//	 Sound_Pwm=Wz_error*sound_P2/100+sound_D2*(sensor.Gyro_deg.z-last_Gyro);
//	 last_sound_err = Sound_error;
//	 last_Gyro=sensor.Gyro_deg.z;
//}*/
void Find_Sound(float belta)
{
	 static float last_sound_err,last_Gyro;
	 Sound_error=belta - err;
	 exp_Wz = sound_P *Sound_error + sound_D * (Sound_error - last_sound_err);
     Wz_error=exp_Wz-sensor.Gyro_deg.z;
	 Sound_Pwm=Wz_error*sound_P2+sound_D2*(sensor.Gyro_deg.z-last_Gyro);
	 last_sound_err = Sound_error;
	 last_Gyro=sensor.Gyro_deg.z;
}


void Location_XY(float R21,float R31,float R41)//TDOA�㷨����Ծ���������
{
	float Delta;
	float x1 = 9, y1 = 5.5, x2 = -9 , y2 = 5.5, x3 = -9 , y3 = -5.5 , x4 = 9 , y4 = -5.5;
	float a1 = 0,a2 = 0,a3 = 0,b1 = 0,b2 = 0,b3 = 0,c1 = 0,c2 = 0,c3 = 0,d1 = 0,d2 = 0,d3 = 0;
    a1 = 2*R21;b1 = 2*(x2 - x1);c1 = 2*(y2 - y1); d1 =( pow(x2,2) + pow(y2,2)) - (pow(x1,2) + pow(y1,2)) - pow(R21,2);
    a2 = 2*R31;b2 = 2*(x3 - x1);c2 = 2*(y3 - y1); d2 =( pow(x3,2) + pow(y3,2)) - (pow(x1,2) + pow(y1,2)) - pow(R31,2);
    a3 = 2*R41;b3 = 2*(x4 - x1);c3 = 2*(y4 - y1); d3 =( pow(x4,2) + pow(y4,2)) - (pow(x1,2) + pow(y1,2)) - pow(R41,2);
    Delta=(a1*(b2*c3 - b3*c2) - b1*(a2*c3 - a3*c2) + c1*(a2*b3 - b2*a3));
    if(Delta!=0)
    {
       Light_X =( a1*(d2*c3 - d3*c2) - d1*(a2*c3 - a3*c2) + c1*(a2*d3 - a3*d2))/Delta;
       Light_Y =( a1*(b2*d3 - b3*d2) - b1*(a2*d3 - a3*d2) + d1*(a2*b3 - a3*b2))/Delta;
       //Light_X=kalmanFilter(Kalman_Init,Light_X);
       //Light_Y=kalmanFilter(Kalman_Init,Light_Y);
       if(my_abs(Light_X)>1000||my_abs(Light_Y)>1000)
       {
    	   Light_X=0;
    	   Light_Y=0;
       }
    }
    else
    {
    	Light_X=0;
    	Light_Y=0;
    }
    Light_D=Light_X*Light_X+Light_Y*Light_Y;
    Light_D=sqrt(Light_D);
}
/*DOA�㷨����Ծ���������*/
void Location_XY_FM(float D1,float D2,float D3)
{
	float Delta;
	float R1,R21,R31;
	float x1 = 5.5, y1 = 5.5, x2 = -5.5 , y2 = 5.5, x3 = 0.0 , y3 =-5.5;
	float a1=0,b1=0,a2=0,b2=0,c1=0,c2=0;
	R1=D1;R21=D2-D1;R31=D3-D1;
	a1=x2-x1;b1=y2-y1;c1=-R21*R1+(pow(x2,2) + pow(y2,2)-pow(x1,2) - pow(y1,2)-pow(R21,2))/2;
	a2=x3-x1;b2=y3-y1;c2=-R31*R1+(pow(x3,2) + pow(y3,2)-pow(x1,2) - pow(y1,2)-pow(R31,2))/2;
	Delta=a1*b2-b1*a2;
	if(Delta!=0)
	{
	  Light_X =(c1*b2-c2*b1)/Delta;
	  Light_Y =(a1*c2-c1*a2)/Delta;
	}
}
void Location_Hyperbola(float D1,float D2)
{
	    const float c=13.6;
		float a1,a2,b1,b2;
		a1=my_abs(D1)/2;
		a2=my_abs(D2)/2;
		b1=sqrt(c*c-a1*a1);
		b2=sqrt(c*c-a2*a2);
		Light_X=a1*b2*sqrt((-(a2*a2 + b1*b1)/((a1*a2 + b1*b2)*(a1*a2 - b1*b2))));
		Light_Y=a2*b1*sqrt((-(a1*a1 + b2*b2)/((a1*a2 + b1*b2)*(a1*a2 - b1*b2))));
}
void Location_Hyperbola1(float D1,float D2)
{
	const float c=13.6;
	float a1,a2,b2;
	float temp1,temp2,sinB;
	sinB=D1/DIS_MIC;
	sinB=my_abs(sinB);
	a1=sinB/sqrt(1-sinB*sinB);
	a2=my_abs(D2)/2;
	b2=sqrt(c*c-a2*a2);
	temp1=a2*a2*b2*b2;
	temp2=a1*a1*b2*b2-a2*a2;
	if(temp2>=0)
	{
		Light_X=sqrt(temp1/temp2);
	    Light_Y=a1*Light_X;
	}
	else
	{
	     Light_X=0;
		 Light_Y=0;
	}
}
