/*
 * Position.h
 *
 *  Created on: 2020��7��3��
 *      Author: zmd123
 */

#ifndef CODE_CALCULATE_CPU1_POSITION_H_
#define CODE_CALCULATE_CPU1_POSITION_H_

void Location_Belta(void);
void Location_XY(float R21,float R31,float R41);
void Location_XY_FM(float D1,float D2,float D3);
void Calculate_Belta(float *B1,float *B2,unsigned short n);
void Location_Hyperbola(float D1,float D2);
void Location_Hyperbola1(float D1,float D2);
void Find_Sound(float belta);
extern float sound_pwm;
extern float sound_P;
extern float sound_D;
extern float d_err;
extern float p_err;
extern float sound_P2,sound_D2;
extern float Sound_error,exp_Wz,Wz_error;
extern float Sound_Pwm;
#endif /* CODE_CALCULATE_CPU1_POSITION_H_ */
