/*
 * Avoid_Stuck.c
 *  Created on: 2020��7��22��
 *      Author: zmd123
 */
#include "Avoid_Stuck.h"
#include "mymath.h"
#include "Speed_Control.h"
#include  "headfile.h"
#include "GlobalVariable.h"
#include <Calculate_CPU1/Position.h>

int stuck_add=0,nostuck_add=0;
int stuck_max=800,nostuck_max=300;
int stucking=0;
int Stuck_PWM=0;
int Speed_Error=10;
void Avoding_Stuck(void)
{
	int OK=0,temp=0;
	float CurSpeed[2] = {curSpeedVy_f, curSpeedVy_b};
	float ExpSpeed[2] ={(lFrontSpeedExp+rFrontSpeedExp)/2,(lBackSpeedExp+rBackSpeedExp)/2};
	float error[2]={ExpSpeed[0]-CurSpeed[0],ExpSpeed[1]-CurSpeed[1]};
	if(my_abs((float)rBackCurSpeed)<5||my_abs((float)lBackCurSpeed)<5||my_abs((float)lFrontCurSpeed)<5||my_abs((float)rFrontCurSpeed)<5)
			temp=1;
		else
			temp=0;
	for(int i = 0; i < 2; i++)
	{
	   if(my_abs(error[i])>Speed_Error&&temp==1
			   &&my_abs((float)CurSpeed[i] + ExpSpeed[i]) == (my_abs((float)CurSpeed[i]) + my_abs(ExpSpeed[i])))
	  	{
	    	if(stuck_add<stuck_max)
	        stuck_add++;
	  	}
	   else
		 OK++;
	}
	if(OK==2&&nostuck_add<nostuck_max)
           nostuck_add++;
	if(nostuck_add==nostuck_max)
	{
		stucking=0;
		stuck_add=0;
		nostuck_add=0;
	}
	if(stuck_add==stuck_max)
	{
		stucking=1;
	}
	if(stucking==1)
	  {
	     if((ExpSpeed[0]+ExpSpeed[1])>=0)
		   Stuck_PWM=-2800;
	     else
		   Stuck_PWM=2800;
	    }
	else
		Stuck_PWM=0;
}

