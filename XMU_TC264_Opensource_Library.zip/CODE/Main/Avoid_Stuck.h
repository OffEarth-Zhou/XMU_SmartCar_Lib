/*
 * Avoid_Stuck.h
 *  Created on: 2020��7��22��
 *      Author: zmd123
 */

#ifndef CODE_MAIN_AVOID_STUCK_H_
#define CODE_MAIN_AVOID_STUCK_H_

void Avoding_Stuck(void);

extern int Stuck_PWM;
extern int stucking;
extern int stuck_add;
extern int stuck_max;
#endif /* CODE_MAIN_AVOID_STUCK_H_ */
