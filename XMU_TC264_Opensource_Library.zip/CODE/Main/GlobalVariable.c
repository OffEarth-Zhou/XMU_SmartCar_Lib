#include "GlobalVariable.h"

//==========================�˵���־==============================//
#pragma section all "cpu0_dsram"
int g_car_lanuch = 0;		 //����������־
int g_drive_flag = 0;           //������ر�־

int lBackCurSpeed = 0;        //�����
int lFrontCurSpeed = 0;       //��ǰ��
int rBackCurSpeed = 0;        //�Һ���
int rFrontCurSpeed = 0;       //��ǰ��
float curSpeedVy = 0;
float curSpeedVy_f = 0;
float curSpeedVy_b = 0;
uint8 Rssi=0;//FM�ź�ǿ��
uint8 last_rssi=0;

#pragma section all restore
//=========================����Ҷ�任�뻥���==================//
#pragma section all "cpu1_dsram"
cfloat32 fft_out[SIZE_N] = {{0,0}};//8k
cfloat32 fft_out1[SIZE_N] = {{0,0}};
//cfloat32 fft_out2[SIZE_N] = {{0,0}};
cfloat32 Cor_Out[SIZE_N]= {{0,0}};


uint16 Mic_1[SIZE_N] = {0,0}; //ԭʼAD�ɼ����ݣ�4*2kb
uint16 Mic_2[SIZE_N] = {0,0};
uint16 Mic_3[SIZE_N] = {0,0};
uint16 Mic_4[SIZE_N] = {0,0};//Fm_Val����
//uint16 FM_Val[SIZE_N] = {0,0};

float Mic_D1=0;  //�����ʱ���
float Mic_D2=0;
float Mic_D3=0;
float Mic_D4=0;
float Delta_T1=0;
float Delta_T2=0;
float Delta_T3=0;
float Belta=0;    //���복ģ�ĽǶ�
float Belta1[100]={0};
float Belta3[100]={0};
float Light_D=0;  //�Ƶľ���
float Light_X=0;  //�Ƶ�����
float Light_Y=0;

int g_plane1=0;  //�ж϶�λ����
int g_plane2=0;
int g_plane3=0;
int g_plane4=0;
int Front=0;
int Back=0;
int Right=0;
int Left=0;
int Lost=0;
//===========================����==============================//
uint8 buf0[9] ;  int idx0 = 0,dist0 = 0;
uint8 buf1[9] ;  int idx1 = 0,dist1 = 0;
uint8 buf2[9] ;  int idx2 = 0,dist2 = 0;
uint8 buf3[9] ;  int idx3 = 0,dist3 = 0;

int jiguang1[2] = {0};
int jiguang2[2] = {0};
int hongwai_bizhang[2] = {0};
int hongwai_dist = 1000;
int jg_flag = 0;
int hongwai[2] = {0};
int hongwai_index = 50;
//==========================����===========================//
float imu_err = 0;
float err = 0;
float delay_time = 420;
float lfpwm = 0,lbpwm = 0,rfpwm = 0,rbpwm = 0;
#pragma section all restore
