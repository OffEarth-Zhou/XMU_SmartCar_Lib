/*
 * GlobalVariable.h
 *
 *  Created on: 2020��6��26��
 *      Author: lenovo
 */

#ifndef CODE_MAIN_GLOBALVARIABLE_H_
#define CODE_MAIN_GLOBALVARIABLE_H_
#include "Ifx_Types.h"
#define SIZE_N 1024
#define DIS_Max 1740.8
#define RSSI_ERR 35
//==========================�˵���־=================================//
extern int g_car_lanuch;				//����������־
extern int g_drive_flag;                //�������


extern int lBackCurSpeed;
extern int lFrontCurSpeed;
extern int rBackCurSpeed;
extern int rFrontCurSpeed;
extern float curSpeedVy;
extern float curSpeedVy_f;
extern float curSpeedVy_b;


//==========================����Ҷ�任�뻥���=====================//
#define DIS_MIC 27.2; //��˷��ľ���
#define S_SPEED 34000;
extern cfloat32 fft_out[SIZE_N];//16k
extern cfloat32 fft_out1[SIZE_N];
//extern cfloat32 fft_out2[SIZE_N];
extern cfloat32 Cor_Out[SIZE_N];
extern uint16 Mic_1[SIZE_N];//4k
extern uint16 Mic_2[SIZE_N];
extern uint16 Mic_3[SIZE_N];
extern uint16 Mic_4[SIZE_N];
//extern uint16 FM_Val[SIZE_N];
extern uint8 Rssi;
extern uint8 last_rssi;


extern float Mic_D1;  //�����ʱ���
extern float Mic_D2;
extern float Mic_D3;
extern float Mic_D4;
extern float Delta_T1;
extern float Delta_T2;
extern float Delta_T3;
extern float Belta;
extern float Belta1[100];
extern float Belta3[100];
extern float Light_D;
extern float Light_X;
extern float Light_Y;

extern int g_plane1;//��Դƽ��
extern int g_plane2;
extern int g_plane3;
extern int g_plane4;
extern int Front;
extern int Back;
extern int Right;
extern int Left;
extern int Lost;
//=============================����=======================//
extern uint8 buf0[9] ;extern int idx0,dist0;
extern uint8 buf1[9] ;extern int idx1,dist1;
extern uint8 buf2[9] ;extern int idx2,dist2;
extern uint8 buf3[9] ;extern int idx3,dist3;
extern int jiguang1[2];
extern int jiguang2[2];
extern int jg_flag;
extern int hongwai[2];
extern int hongwai_bizhang[2];
extern int hongwai_dist;
extern int hongwai_index;
//===========================����========================//
extern float imu_err;
extern float delay_time;
extern float err;
extern float lfpwm,lbpwm,rfpwm,rbpwm;
#endif
