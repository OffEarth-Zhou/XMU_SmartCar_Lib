/*
 * Speed_Control.c
 *  Created on: 2020��7��18��
 *      Author: zmd123
 */
#include "Speed_Control.h"
#include  "headfile.h"
#include "GlobalVariable.h"
#include <Calculate_CPU1/Position.h>
#include "zf_gpt12.h"
#include "Avoid_Stuck.h"
#include "mymath.h"
#include "mpu_prepare.h"

float Vy =0;//2.0

float driveI =100;
float driveP =1000;
float driveD = 0;

float Vy1 = 40;
float Vy2 = 15;
float Vy3 = 10;
float Vy4 = 0;
int suoxiao=100;

float lBackDuty = 0;
float lFrontDuty = 0;
float rBackDuty = 0;
float rFrontDuty = 0;

 int lfPWM = 0 ;
 int rfPWM = 0 ;
 int lbPWM = 0;
 int rbPWM = 0 ;

float rF_error_next = 0;  //������һ��ƫ��ֵ
float rF_error_last = 0;  //��������ǰ��ƫ��ֵ
float lF_error_next = 0;
float lF_error_last = 0;
float rB_error_next = 0;
float rB_error_last = 0;
float lB_error_next = 0;
float lB_error_last = 0;

float lFrontSpeedExp = 0;
float rFrontSpeedExp = 0;
float lBackSpeedExp = 0;
float rBackSpeedExp = 0;

int bizhang_dist = 50;
float jiguang_error =20;
float bizhang_p = /*70*/5;
float bizhang_d = 0;
float bizhang_pwm = 80;


float Bizhang_Pwm = 0;

int bizhang1[2] = {0};
int bizhang2[2] = {0};

 float bizhang_error = 0;
 float last_bizhang_error = 0;
float Bizhang_buchong = 20;
int count_N=24;

 float speed_max = 200;
 float Straight_PWM = 0;
 int straight_count = 0;
 int g_straight_flag = 0;
 void SpeedGet(void)
  {
      //�����ȡ
 	 lFrontCurSpeed = gpt12_get(GPT12_T6);
       rFrontCurSpeed= -gpt12_get(GPT12_T2);
       lBackCurSpeed = gpt12_get(GPT12_T4);
       rBackCurSpeed= -gpt12_get(GPT12_T5);
      gpt12_clear(GPT12_T2);
      gpt12_clear(GPT12_T4);
      gpt12_clear(GPT12_T5);
      gpt12_clear(GPT12_T6);
      curSpeedVy =(float) (rBackCurSpeed + lBackCurSpeed + lFrontCurSpeed + rFrontCurSpeed) / 4 ;
      curSpeedVy_b = (float) (rBackCurSpeed + lFrontCurSpeed)/2;
      curSpeedVy_f = (float) (lBackCurSpeed + rFrontCurSpeed)/2;
  }
void ExpectSpeedGet(void)
{

		if(Front ==1)

		  {
				lFrontSpeedExp = Vy+bizhang_error;
				rFrontSpeedExp = Vy-bizhang_error;
				lBackSpeedExp = Vy-bizhang_error;
				rBackSpeedExp = Vy+bizhang_error;
	    }

					if(Back==1)
			{
							lFrontSpeedExp = -Vy-bizhang_error;
							rFrontSpeedExp = -Vy+bizhang_error;
							lBackSpeedExp = -Vy+bizhang_error;
							rBackSpeedExp = -Vy-bizhang_error;

	     	}


			if(lFrontSpeedExp>speed_max)
				lFrontSpeedExp=speed_max;
			if(lFrontSpeedExp<-speed_max)
				lFrontSpeedExp=-speed_max;
           if(rFrontSpeedExp>speed_max)
        	   rFrontSpeedExp=speed_max;
		  if(rFrontSpeedExp<-speed_max)
			  rFrontSpeedExp=-speed_max;
		if(lBackSpeedExp>speed_max)
			lBackSpeedExp=speed_max;
		if(lBackSpeedExp<-speed_max)
			lBackSpeedExp=-speed_max;
		if(rBackSpeedExp>speed_max)
			rBackSpeedExp=speed_max;
	    if(rBackSpeedExp<-speed_max)
	    	rBackSpeedExp=-speed_max;
}

void RightBackDutyCalc(void)
{
    float error;  //����ƫ��ֵ
    error =rBackSpeedExp - curSpeedVy_b;
    float incrementSpeed = driveP/*_rb*//suoxiao*(error-rB_error_next)+driveI/*_rb*//suoxiao*error+driveD/suoxiao*
        (error-2*rB_error_next+rB_error_last);
    rBackDuty += incrementSpeed;
    rB_error_last = rB_error_next;
    rB_error_next = error;
    if (rBackDuty > 10000)
    {
        rBackDuty = 9999;
    }
    if (rBackDuty < -10000)
    {
        rBackDuty = -9999;
    }
}
void RightFrontDutyCalc(void)
{
     float error;  //����ƫ��ֵ
    error =rFrontSpeedExp - curSpeedVy_f;
    float incrementSpeed = driveP/*_rf*//suoxiao/*_rf*/*(error-rF_error_next)+driveI/*_rf*//suoxiao*error+driveD*
        (error-2*rF_error_next+rF_error_last);
    rFrontDuty += incrementSpeed;
    rF_error_last = rF_error_next;
    rF_error_next = error;
    if (rFrontDuty > 10000)
    {
        rFrontDuty = 9999;
    }
    if (rFrontDuty < -10000)
    {
        rFrontDuty = -9999;
    }
}

void LeftFrontDutyCalc(void)
{
     float error;  //����ƫ��ֵ
    error = lFrontSpeedExp - curSpeedVy_b;
    float incrementSpeed = driveP/suoxiao*(error-lF_error_next)+driveI/suoxiao*error+driveD/suoxiao*
        (error-2*lF_error_next+lF_error_last);
    lFrontDuty += incrementSpeed;
    lF_error_last = lF_error_next;
    lF_error_next = error;
    if (lFrontDuty > 10000)
    {
        lFrontDuty = 9999;
    }
    if (lFrontDuty < -10000)
    {
        lFrontDuty = -9999;
    }
}
void LeftBackDutyCalc(void)
{
    float error;  //����ƫ��ֵ
    error =lBackSpeedExp - curSpeedVy_f;
    float incrementSpeed = driveP/*_lb*//suoxiao*(error-lB_error_next)+driveI/*_lb*//suoxiao*error+driveD/suoxiao*
        (error-2*lB_error_next+lB_error_last);
    lBackDuty+=incrementSpeed;
    lB_error_last = lB_error_next;
    lB_error_next = error;
    if (lBackDuty > 10000)
    {
        lBackDuty = 9999;
    }
    if (lBackDuty < -10000)
    {
        lBackDuty = -9999;
    }
}
void PwmOutput(void)
{
  float PWM[4] = {lfPWM, rfPWM, rbPWM, lbPWM};

	  rfPWM =rFrontDuty-Sound_Pwm;
	  lfPWM =lFrontDuty+Sound_Pwm;
	  lbPWM =lBackDuty+Sound_Pwm;
	  rbPWM =rBackDuty-Sound_Pwm;

      if (rfPWM > 10000)
        {
    	  rfPWM = 9999;
        }
        if (rfPWM < -10000)
        {
        	rfPWM = -9999;
        }
        if (lfPWM > 10000)
              {
        	lfPWM = 9999;
              }
              if (lfPWM < -10000)
              {
            	  lfPWM = -9999;
              }
              if (lbPWM > 10000)
                           {
            	  lbPWM = 9999;
                           }
                           if (lbPWM < -10000)
                           {
                        	   lbPWM = -9999;
                           }
                           if (rbPWM > 10000)
                                        {
                        	   rbPWM = 9999;
                                        }
                                        if (rbPWM < -10000)
                                        {
                                        	rbPWM = -9999;
                                        }



    if(PWM[0] >= 0)
        {
            pwm_duty(ATOM0_CH6_P02_6, 0);
            pwm_duty(ATOM0_CH7_P02_7, PWM[0]);
        }
        else
        {
            pwm_duty(ATOM0_CH6_P02_6, -PWM[0]);
            pwm_duty(ATOM0_CH7_P02_7,0 );
        }

        if(PWM[1] >= 0)
        {
            pwm_duty(ATOM0_CH4_P02_4, PWM[1]);
            pwm_duty(ATOM0_CH5_P02_5, 0);
        }
        else
        {
            pwm_duty(ATOM0_CH4_P02_4, 0);
            pwm_duty(ATOM0_CH5_P02_5,-PWM[1]);
        }

        if(PWM[2] >= 0)
        {
            pwm_duty(ATOM0_CH1_P21_3,  0);
            pwm_duty(ATOM1_CH0_P21_2, PWM[2]);
        }
        else
        {
            pwm_duty(ATOM0_CH1_P21_3, -PWM[2]);
            pwm_duty(ATOM1_CH0_P21_2, 0);
        }

        if(PWM[3] >= 0)
        {
            pwm_duty(ATOM0_CH3_P21_5,0);
            pwm_duty( ATOM1_CH2_P21_4,PWM[3] );
        }
        else
        {
            pwm_duty(ATOM0_CH3_P21_5, -PWM[3]);
            pwm_duty(ATOM1_CH2_P21_4, 0);
        }
}
void Bizhang(int index)//����index,0ǰ1��
{
	//���ڼ��������
//	static float last_sensor_GyroZ = 0;

	  if(jiguang1[index] <= bizhang_dist)//�ж��Ƿ�Ҫ��������
	        bizhang1[index] = 1;
	    else
	        bizhang1[index] = 0;

	    if(jiguang2[index] <= bizhang_dist)
	        bizhang2[index] = 1;
	    else
	        bizhang2[index] = 0;
	    if(hongwai[index] >= hongwai_dist)
             hongwai_bizhang[index] = 1;
	    else
	    	hongwai_bizhang[index] = 0;


	    	if(bizhang1[index]!=0||bizhang2[index]!=0)
	    	{
	       	  if(bizhang1[index]!=0)
	       	  {
	       		  if(bizhang2[index]!=0)
	       		  {
                       if(my_abs((float)(jiguang1[index] - jiguang2[index]))< jiguang_error)
                    	   bizhang_error = bizhang_pwm;
                       else if(jiguang1[index] < jiguang2[index])
	       		    		bizhang_error = bizhang_pwm;
	       		    	 else
	       		    		 bizhang_error = -bizhang_pwm;


	       		  }
	       		  else
	       			  bizhang_error =bizhang_pwm;
	       	  }
	       	  else
	       		  bizhang_error =-bizhang_pwm;
	    	}

	    	else  if(hongwai_bizhang[index])
	    		bizhang_error = bizhang_pwm;



	    else bizhang_error = 0;

  }

void NO_PWM(void)
{
    pwm_duty(ATOM0_CH6_P02_6, 0);
    pwm_duty(ATOM0_CH7_P02_7, 0);

    pwm_duty(ATOM0_CH4_P02_4, 0);
    pwm_duty(ATOM0_CH5_P02_5, 0);

    pwm_duty(ATOM0_CH1_P21_3, 0);
    pwm_duty(ATOM1_CH0_P21_2, 0);

    pwm_duty(ATOM0_CH3_P21_5, 0);
    pwm_duty( ATOM1_CH2_P21_4,0);

}
void straight(int index)
{
	static int close_bizhang = 0;
	static int l_close_bizhang = 0;

	l_close_bizhang = close_bizhang;
	close_bizhang = bizhang1[index] || bizhang2[index];
    if(close_bizhang == 0 && l_close_bizhang ==1)
    	g_straight_flag = 1;
    if(g_straight_flag ==1)
    {
    	straight_count++;
    	if(index == 0)
    		Straight_PWM = 2000;
    	else
    		Straight_PWM = -2000;
    }


    if(straight_count == delay_time)
    {
    	g_straight_flag = 0;
    	straight_count = 0;

    }
 }
void New_direction(void)
{
	static int jg[100] = {0};
	static int count_jg = 0;
	static int open_flag = 0;

	int sum = 0;
	jg[count_jg] = jg_flag;
	count_jg++;
	if(count_jg == count_N)
	{
		open_flag = 1;
		count_jg = 0;
	}
	if(open_flag ==1)
	{
		for(int i = 0; i < count_N; i++)

			sum += jg[i];

		if(sum >=count_N*0.5)
		{
			Front =0;
			Back = 1;
		}
		else	if(sum <=count_N*0.25)
//		if(sum <=20)
		{
			Front = 1;
			Back = 0;
		}
		else
		{
			Back =0;
			Front =0;

		}
	}
}

