/*
 * Speed_Control.h
 *
 *  Created on: 2020��7��18��
 *      Author: zmd123
 */

#ifndef CODE_MAIN_SPEED_CONTROL_H_
#define CODE_MAIN_SPEED_CONTROL_H_

extern float driveI;
extern float driveP;
extern float driveD;

void SpeedGet(void);
void ExpectSpeedGet(void);
void RightBackDutyCalc(void);
void RightFrontDutyCalc(void);
void LeftFrontDutyCalc(void);
void LeftBackDutyCalc(void);
void PwmOutput(void);
void Bizhang(int index);
void NO_PWM(void);
void straight(int index);
void New_direction(void);
extern float rF_error_next;  //������һ��ƫ��ֵ
extern float rF_error_last;  //��������ǰ��ƫ��ֵ
extern float lF_error_next;
extern float lF_error_last;
extern float rB_error_next;
extern float rB_error_last;
extern float lB_error_next;
extern float lB_error_last;


extern float lBackDuty;
extern float lFrontDuty;
extern float rBackDuty;
extern float rFrontDuty;

extern int lfPWM ;
extern int rfPWM ;
extern int lbPWM ;
extern int rbPWM ;
extern float S_Ratio;


extern float lFrontSpeedExp;
extern float rFrontSpeedExp;
extern float lBackSpeedExp;
extern float rBackSpeedExp;


#define  TIRE_PARAMETER_A		 36.41      //       1/[R*tan(��)]
#define  TIRE_PARAMETER_B		 32.79      //       1/R
#define  TIRE_PARAMETER_C		 6.20      //       [L1*tan(��)+L2]/[R*tan(��)]

extern float bizhang_error ;
extern float last_bizhang_error;
extern float bizhang_pwm;

extern float bizhang_p;
extern float bizhang_d;


extern int bizhang_dist;
extern float jiguang_error;
extern float Vy ;
extern float Bizhang_Pwm;

extern float Vb;
extern float Vs;
extern float speed_max;

extern float Vy1 ;
extern float Vy2 ;
extern float Vy3 ;
extern float Vy4 ;

extern int straight_count ;
extern int g_straight_flag ;
extern float Straight_PWM;
#endif /* CODE_MAIN_SPEED_CONTROL_H_ */
